export const API_KEY = '48650e17efce474fba5d880ebf6a77e1';
export const API_BASE = 'https://newsapi.org/v2/';